from flask import Flask, request, render_template, session, url_for, redirect, flash
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import text
import secrets

app = Flask(__name__)

# SQLAlchemy 
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:krishnaprabhu#1@localhost/dummy'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = secrets.token_hex(16)
db = SQLAlchemy(app)

#login
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        sql = text("SELECT * FROM user WHERE username = :username")
        user = db.session.execute(sql, {"username": username}).fetchone()

        if user and user._mapping['user_password'] == password:  # Checking password
            session['user_id'] = user._mapping['User_id']
            session['family_head_id'] = user._mapping['family_head_id']
            return redirect(url_for('home'))
        else:
            flash('Invalid credentials')
            return redirect(url_for('login'))

    return render_template('login.html')


#home
@app.route('/home')
def home():
    user_id = session.get('user_id')
    family_head_id = session.get('family_head_id')

    sql = text("""
        SELECT * FROM savings_goals
        WHERE 
            (Goal_type = 'Personal' AND User_id = :user_id)
            OR
            (Goal_type = 'Family' AND family_head_id = :family_head_id)
    """)
    
    savings_goals = db.session.execute(sql, {"user_id": user_id, "family_head_id": family_head_id}).fetchall()

    return render_template("home.html", datas=savings_goals)

#add amount 
@app.route("/add_amount/<string:id>", methods=["GET", "POST"])
def add_amount(id):
    user_id = session.get("user_id")
    family_head_id = session.get("family_head_id")

    sql = text("""
        SELECT * FROM Savings_goals 
        WHERE Goal_id = :goal_id AND (User_id = :user_id OR family_head_id = :family_head_id)
    """)
    goal = db.session.execute(sql, {"goal_id": id, "user_id": user_id, "family_head_id": family_head_id}).fetchone()

    if not goal:
        flash("Goal not found")
        return redirect(url_for("home"))

    if request.method == "POST":
        additional_amount = float(request.form["additional_amount"])

        # Update achieved_amount
        update_sql = text("""
            UPDATE Savings_goals 
            SET achieved_amount = COALESCE(achieved_amount, 0) + :amount
            WHERE Goal_id = :goal_id AND (User_id = :user_id OR family_head_id = :family_head_id)
        """)
        db.session.execute(update_sql, {
            "amount": additional_amount,
            "goal_id": id,
            "user_id": user_id,
            "family_head_id": family_head_id
        })

        # Update goal status
        goal = db.session.execute(sql, {"goal_id": id, "user_id": user_id, "family_head_id": family_head_id}).fetchone()
        achieved_amount = goal._mapping["Achieved_amount"]
        target_amount = goal._mapping["Target_amount"]

        status = "completed" if achieved_amount >= target_amount else "on-going"
        status_sql = text("""
            UPDATE Savings_goals 
            SET Goal_status = :status
            WHERE Goal_id = :goal_id AND (User_id = :user_id OR family_head_id = :family_head_id)
        """)
        db.session.execute(status_sql, {"status": status, "goal_id": id, "user_id": user_id, "family_head_id": family_head_id})
        db.session.commit()

        flash("Amount Added Successfully!")
        return redirect(url_for("home"))

    return render_template("add_amount.html", data=goal)

#add goal
@app.route("/addgoal", methods=['GET', 'POST'])
def add_Goal():
    family_head_id = session.get('family_head_id')
    user_id = session.get('user_id')

    if request.method == "POST":
        target_amount = request.form['target_amount']
        start_date = request.form['start_date']
        end_date = request.form['end_date']
        goal_status = request.form['goal_status']
        goal_description = request.form['goal_description']
        achieved_amount = request.form['achieved_amount']
        goal_type = request.form['goal_type']

        sql = text("""
            INSERT INTO Savings_goals 
            (User_id, family_head_id, Target_amount, start_date, end_date, Goal_status, Goal_description, Achieved_amount, Goal_type)
            VALUES (:user_id, :family_head_id, :target_amount, :start_date, :end_date, :goal_status, :goal_description, :achieved_amount, :goal_type)
        """)
        db.session.execute(sql, {
            "user_id": user_id,
            "family_head_id": family_head_id,
            "target_amount": target_amount,
            "start_date": start_date,
            "end_date": end_date,
            "goal_status": goal_status,
            "goal_description": goal_description,
            "achieved_amount": achieved_amount,
            "goal_type": goal_type
        })
        db.session.commit()

        flash("Goal Added Successfully")
        return redirect(url_for('home'))

    return render_template("addgoals.html")

#edit goal
@app.route("/edit_Goals/<string:id>", methods=['GET', 'POST'])
def edit_Goals(id):
    user_id = session.get('user_id')

    if request.method == 'POST':
        target_amount = request.form['target_amount']
        start_date = request.form['start_date']
        end_date = request.form['end_date']
        goal_status = request.form['goal_status']
        goal_description = request.form['goal_description']
        achieved_amount = request.form['achieved_amount']
        goal_type = request.form['goal_type']

        sql = text("""
            UPDATE Savings_goals 
            SET Target_amount = :target_amount, start_date = :start_date, end_date = :end_date, 
                Goal_status = :goal_status, Goal_description = :goal_description, 
                Achieved_amount = :achieved_amount, Goal_type = :goal_type
            WHERE Goal_id = :goal_id AND User_id = :user_id
        """)
        db.session.execute(sql, {
            "target_amount": target_amount,
            "start_date": start_date,
            "end_date": end_date,
            "goal_status": goal_status,
            "goal_description": goal_description,
            "achieved_amount": achieved_amount,
            "goal_type": goal_type,
            "goal_id": id,
            "user_id": user_id
        })
        db.session.commit()

        flash("Goal Updated Successfully")
        return redirect(url_for("home"))

    sql = text("SELECT * FROM Savings_goals WHERE Goal_id = :goal_id")
    goal = db.session.execute(sql, {"goal_id": id}).fetchone()

    return render_template("editgoals.html", datas=goal)

#delete goal
@app.route("/delete_Goals/<string:id>", methods=['GET', 'POST'])
def delete_Goals(id):
    user_id = session.get('user_id')

    sql = text("DELETE FROM Savings_goals WHERE Goal_id = :goal_id AND User_id = :user_id")
    db.session.execute(sql, {"goal_id": id, "user_id": user_id})
    db.session.commit()

    flash('Goal Deleted Successfully')
    return redirect(url_for("home"))


if __name__ == '__main__':
    app.run(debug=True)
